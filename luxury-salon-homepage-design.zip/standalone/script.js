/* =========================================
   XXXX UNISEX SALON — Premium Luxury JS
   ========================================= */

// ── PRELOADER ──
document.addEventListener('DOMContentLoaded', () => {
  const preloader = document.getElementById('preloader');
  const progressBar = document.querySelector('.progress-bar');
  const pctText = document.querySelector('.pct');
  let progress = 0;

  const loadInterval = setInterval(() => {
    progress += 1.25;
    if (progress >= 100) {
      progress = 100;
      clearInterval(loadInterval);
      setTimeout(() => {
        preloader.classList.add('hidden');
      }, 400);
    }
    progressBar.style.width = progress + '%';
    pctText.textContent = Math.floor(progress) + '%';
  }, 20);
});

// ── NAVBAR SCROLL ──
const navbar = document.getElementById('navbar');

window.addEventListener('scroll', () => {
  if (window.scrollY > 40) {
    navbar.classList.add('scrolled');
  } else {
    navbar.classList.remove('scrolled');
  }
  updateActiveNav();
});

// ── ACTIVE SECTION TRACKING ──
function updateActiveNav() {
  const sections = ['home', 'services', 'about', 'reviews', 'why-us', 'contact'];
  const scrollPos = window.scrollY + 300;

  sections.forEach(id => {
    const el = document.getElementById(id);
    if (el) {
      const top = el.offsetTop;
      const height = el.offsetHeight;
      const link = document.querySelector(`.nav-link[data-section="${id}"]`);
      const mobileLink = document.querySelector(`.mobile-nav-link[data-section="${id}"]`);

      if (scrollPos >= top && scrollPos < top + height) {
        document.querySelectorAll('.nav-link').forEach(l => l.classList.remove('active'));
        document.querySelectorAll('.mobile-nav-link').forEach(l => l.classList.remove('active'));
        if (link) link.classList.add('active');
        if (mobileLink) mobileLink.classList.add('active');
      }
    }
  });
}

// ── SMOOTH SCROLL NAVIGATION ──
document.querySelectorAll('.nav-link, .mobile-nav-link').forEach(link => {
  link.addEventListener('click', (e) => {
    e.preventDefault();
    const id = link.getAttribute('data-section');
    closeMobileMenu();

    setTimeout(() => {
      if (id === 'home') {
        window.scrollTo({ top: 0, behavior: 'smooth' });
      } else {
        const el = document.getElementById(id);
        if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    }, 50);
  });
});

// ── MOBILE MENU ──
const hamburger = document.getElementById('hamburger');
const mobileMenu = document.getElementById('mobile-menu');

hamburger.addEventListener('click', () => {
  mobileMenu.classList.toggle('open');
  const icon = hamburger.querySelector('svg');
  if (mobileMenu.classList.contains('open')) {
    icon.innerHTML = '<line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line>';
  } else {
    icon.innerHTML = '<line x1="3" y1="12" x2="21" y2="12"></line><line x1="3" y1="6" x2="21" y2="6"></line><line x1="3" y1="18" x2="21" y2="18"></line>';
  }
});

function closeMobileMenu() {
  mobileMenu.classList.remove('open');
  const icon = hamburger.querySelector('svg');
  icon.innerHTML = '<line x1="3" y1="12" x2="21" y2="12"></line><line x1="3" y1="6" x2="21" y2="6"></line><line x1="3" y1="18" x2="21" y2="18"></line>';
}

// ── HERO BACKGROUND SLIDESHOW ──
const heroImages = document.querySelectorAll('.hero-bg img');
let currentBg = 0;

setInterval(() => {
  heroImages[currentBg].classList.remove('active');
  currentBg = (currentBg + 1) % heroImages.length;
  heroImages[currentBg].classList.add('active');
}, 6000);

// ── SCROLL REVEAL ANIMATION ──
const revealElements = document.querySelectorAll('.reveal');

const revealObserver = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add('visible');
    }
  });
}, { threshold: 0.1, rootMargin: '-50px' });

revealElements.forEach(el => revealObserver.observe(el));

// ── COUNTER ANIMATION ──
const counterElements = document.querySelectorAll('.counter-value');
let countersAnimated = false;

const counterObserver = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting && !countersAnimated) {
      countersAnimated = true;
      animateCounters();
    }
  });
}, { threshold: 0.3 });

const countersSection = document.querySelector('.counters-grid');
if (countersSection) counterObserver.observe(countersSection);

function animateCounters() {
  counterElements.forEach(el => {
    const target = parseFloat(el.getAttribute('data-target'));
    const suffix = el.getAttribute('data-suffix') || '';
    const duration = 2000;
    const start = performance.now();

    function step(now) {
      const progress = Math.min((now - start) / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      const current = Math.floor(eased * target);
      el.textContent = current + suffix;
      if (progress < 1) requestAnimationFrame(step);
    }

    requestAnimationFrame(step);
  });
}

// ── TOAST SYSTEM ──
function showToast(message) {
  const toast = document.getElementById('toast');
  const toastMsg = document.getElementById('toast-message');
  toastMsg.textContent = message;
  toast.classList.add('show');
  setTimeout(() => toast.classList.remove('show'), 4000);
}

// ── SIMULATED ACTIONS (no real calls/messages) ──
document.querySelectorAll('[data-action="call"]').forEach(el => {
  el.addEventListener('click', (e) => {
    e.preventDefault();
    showToast("Direct call feature is disabled in this template. Please book via the form.");
  });
});

document.querySelectorAll('[data-action="whatsapp"]').forEach(el => {
  el.addEventListener('click', (e) => {
    e.preventDefault();
    showToast("WhatsApp booking simulated! External messages are disabled in this template.");
  });
});

document.querySelectorAll('[data-action="social"]').forEach(el => {
  el.addEventListener('click', (e) => {
    e.preventDefault();
    showToast("Social link simulated! Outgoing requests are disabled in this template.");
  });
});

// ── BOOKING FORM ──
const bookingForm = document.getElementById('booking-form');
const formSuccess = document.getElementById('form-success');

if (bookingForm) {
  bookingForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const name = document.getElementById('form-name').value;
    const service = document.getElementById('form-service').value;

    if (!name || !document.getElementById('form-phone').value) return;

    bookingForm.style.display = 'none';
    formSuccess.style.display = 'flex';

    document.getElementById('success-name').textContent = name;
    document.getElementById('success-service').textContent = service;
  });
}

function resetForm() {
  bookingForm.style.display = 'block';
  formSuccess.style.display = 'none';
  bookingForm.reset();
}

// ── SCROLL TO TOP ──
function scrollToTop() {
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

// ── FLOATING BOOKING NOTIFICATIONS ──
const bookingNotifications = [
  { name: 'Priya S.', service: 'Keratin & Smoothening', time: 'Just now' },
  { name: 'Rahul V.', service: 'Schwarzkopf Hair Spa', time: '2 mins ago' },
  { name: 'Simran K.', service: 'Bridal HD Makeup Trial', time: '5 mins ago' },
  { name: 'Amit M.', service: 'Executive Beard Styling', time: '12 mins ago' },
];

let notifIndex = 0;
const notifEl = document.getElementById('booking-notif');

function showBookingNotif() {
  if (!notifEl) return;
  const data = bookingNotifications[notifIndex];
  document.getElementById('notif-name').textContent = data.name;
  document.getElementById('notif-service').textContent = data.service;
  document.getElementById('notif-time').textContent = data.time;
  notifEl.classList.add('show');

  setTimeout(() => {
    notifEl.classList.remove('show');
    notifIndex = (notifIndex + 1) % bookingNotifications.length;
  }, 5000);
}

setTimeout(() => showBookingNotif(), 4000);
setInterval(() => showBookingNotif(), 15000);

function closeNotif() {
  notifEl.classList.remove('show');
}

// ── PARTICLE BACKGROUND ──
const canvas = document.getElementById('particle-canvas');
if (canvas) {
  const ctx = canvas.getContext('2d');
  let w = canvas.width = window.innerWidth;
  let h = canvas.height = window.innerHeight;

  window.addEventListener('resize', () => {
    w = canvas.width = window.innerWidth;
    h = canvas.height = window.innerHeight;
  });

  const particles = [];
  for (let i = 0; i < 40; i++) {
    particles.push({
      x: Math.random() * w,
      y: Math.random() * h,
      size: Math.random() * 2 + 0.8,
      speedY: -(Math.random() * 0.3 + 0.1),
      speedX: (Math.random() - 0.5) * 0.2,
      opacity: Math.random() * 0.4 + 0.1,
      pulse: Math.random() * Math.PI,
      pulseSpeed: Math.random() * 0.02 + 0.005
    });
  }

  function renderParticles() {
    ctx.clearRect(0, 0, w, h);

    const g = ctx.createRadialGradient(w * 0.2, h * 0.3, 0, w * 0.2, h * 0.3, w * 0.5);
    g.addColorStop(0, 'rgba(212,175,55,0.03)');
    g.addColorStop(1, 'rgba(11,11,13,0)');
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, w, h);

    particles.forEach(p => {
      p.y += p.speedY;
      p.x += p.speedX;
      if (p.y < -10) { p.y = h + 10; p.x = Math.random() * w; }
      if (p.x < -10) p.x = w + 10;
      if (p.x > w + 10) p.x = -10;
      p.pulse += p.pulseSpeed;

      const op = Math.max(0.05, Math.min(0.6, p.opacity + Math.sin(p.pulse) * 0.15));
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
      ctx.fillStyle = `rgba(212,175,55,${op})`;
      ctx.shadowBlur = 8;
      ctx.shadowColor = 'rgba(212,175,55,0.3)';
      ctx.fill();
      ctx.shadowBlur = 0;
    });

    requestAnimationFrame(renderParticles);
  }

  renderParticles();
}
